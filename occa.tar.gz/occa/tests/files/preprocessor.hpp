#ifndef ERROR
0 1 2 3 4
#else
#  error "Found the testing error"
#endif
